const RepairPage = () => {
  return <div>Information about repair.</div>;
};

export default RepairPage;
