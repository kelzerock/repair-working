import { FAQ } from "@/components/faq";

const FAQPage = () => {
  return <FAQ />;
};

export default FAQPage;
