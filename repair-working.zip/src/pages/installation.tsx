const InstallationPage = () => {
  return <div>Information about installation.</div>;
};

export default InstallationPage;
