(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 1403:
/***/ ((module) => {

// Exports
module.exports = {
	"header_firm_info": "firmInfo_header_firm_info__koK0Y"
};


/***/ }),

/***/ 1589:
/***/ ((module) => {

// Exports
module.exports = {
	"header_phone": "headerPhone_header_phone__OcwGK",
	"phone_img": "headerPhone_phone_img__Nlp_R"
};


/***/ }),

/***/ 2231:
/***/ ((module) => {

// Exports
module.exports = {
	"logo": "logo_logo__4rw1x"
};


/***/ }),

/***/ 5234:
/***/ ((module) => {

// Exports
module.exports = {
	"menu": "burger_menu__pFWkT",
	"nav_burger": "burger_nav_burger__sG0ps",
	"hidden": "burger_hidden__5IalV",
	"visible": "burger_visible__Kcp3t",
	"first_ul": "burger_first_ul__39l3_",
	"list_elem": "burger_list_elem__9QJ75",
	"header_link": "burger_header_link__w5zcU",
	"sub_nav": "burger_sub_nav__IlWQZ",
	"sub_header": "burger_sub_header__cptg1",
	"img": "burger_img__GzStt",
	"rotateImg": "burger_rotateImg__eIDoB",
	"sub_nav_list": "burger_sub_nav_list__x8pAA",
	"sub_hidden": "burger_sub_hidden__317C3",
	"burger_menu": "burger_burger_menu__2E3Is",
	"burger_bar": "burger_burger_bar__EQ6en",
	"unclicked": "burger_unclicked__rZQpM",
	"clicked": "burger_clicked__b_X6A"
};


/***/ }),

/***/ 273:
/***/ ((module) => {

// Exports
module.exports = {
	"nav": "nav_nav__wogdB",
	"header_sub_link": "nav_header_sub_link__YUB9j",
	"nav_arrow": "nav_nav_arrow__w_Xrw",
	"nav_arrow_black": "nav_nav_arrow_black__T38a1",
	"addiction_nav": "nav_addiction_nav__xCmqq",
	"hidden": "nav_hidden__QZ8Ln"
};


/***/ }),

/***/ 9735:
/***/ ((module) => {

// Exports
module.exports = {
	"header_wrapper": "header_header_wrapper__PFifY",
	"header": "header_header__3RG80",
	"header_btn": "header_header_btn__wAKn1"
};


/***/ }),

/***/ 6464:
/***/ ((module) => {

// Exports
module.exports = {
	"layout_main": "layout_layout_main__hI1Vj"
};


/***/ }),

/***/ 2312:
/***/ ((module) => {

// Exports
module.exports = {
	"block": "advertise_block__ptsb7",
	"wrapper": "advertise_wrapper__CXVIx",
	"block_img": "advertise_block_img__ZB_cC",
	"img_fridge": "advertise_img_fridge__tDXAm",
	"img_master": "advertise_img_master__jNPFE",
	"block_info": "advertise_block_info__6kCAg",
	"info_phone": "advertise_info_phone__IEucC"
};


/***/ }),

/***/ 8231:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "footer_footer__ZK5Q_",
	"icon": "footer_icon__TOBX_",
	"firstblock": "footer_firstblock__DQTVR",
	"social": "footer_social___wMxI",
	"contacts": "footer_contacts__2QrVB",
	"contacts_container": "footer_contacts_container__L7_9K",
	"phones": "footer_phones__Ielya",
	"secondblock": "footer_secondblock__95yW1",
	"customer": "footer_customer__3HN8H"
};


/***/ }),

/***/ 7696:
/***/ ((module) => {

// Exports
module.exports = {
	"service": "services_service__Sm7Yp",
	"service_ul": "services_service_ul__nuYpW",
	"service_name": "services_service_name__u1Lx6",
	"service_li": "services_service_li__2zp5V",
	"service_mobile": "services_service_mobile__lTvsS",
	"service_desktop": "services_service_desktop__N42hG"
};


/***/ }),

/***/ 6677:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _firmInfo_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1403);
/* harmony import */ var _firmInfo_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_firmInfo_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants_json_about_firm_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2997);




const info = [
    `с ${_constants_json_about_firm_json__WEBPACK_IMPORTED_MODULE_2__/* .time.start */ .XV.B} до ${_constants_json_about_firm_json__WEBPACK_IMPORTED_MODULE_2__/* .time.end */ .XV.u} без выходных`,
    "Бесплатная диагностика",
    "Гарантия до 2 лет"
];
const FirmInfo = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
        className: (_firmInfo_module_scss__WEBPACK_IMPORTED_MODULE_3___default().header_firm_info),
        children: info.map((el, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        src: `/images/header/header${index}.svg`,
                        width: "0",
                        height: "0",
                        alt: "done img",
                        sizes: "100vw"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: el
                    })
                ]
            }, index))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FirmInfo);


/***/ }),

/***/ 7981:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6851);
/* harmony import */ var _FirmInfo_FirmInfo_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6677);
/* harmony import */ var _header_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9735);
/* harmony import */ var _header_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_header_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _HeaderPhone_HeaderPhone_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2142);
/* harmony import */ var _Logo_logo_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1300);
/* harmony import */ var _Nav_Burger_Burger_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2476);
/* harmony import */ var _Nav_Nav_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4158);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_modal__WEBPACK_IMPORTED_MODULE_3__]);
_modal__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const Header = ()=>{
    const [isShowingModal, setIsShowingModal] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_header_module_scss__WEBPACK_IMPORTED_MODULE_9___default().header_wrapper),
        children: [
            isShowingModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modal__WEBPACK_IMPORTED_MODULE_3__/* .Modal */ .u, {
                isShowingModal: isShowingModal,
                setIsShowingModal: setIsShowingModal,
                typeOfModal: "call"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_header_module_scss__WEBPACK_IMPORTED_MODULE_9___default().header),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Logo_logo_component__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FirmInfo_FirmInfo_component__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HeaderPhone_HeaderPhone_component__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Nav_Nav_component__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("btn-yellow", (_header_module_scss__WEBPACK_IMPORTED_MODULE_9___default().header_btn)),
                            onClick: (e)=>{
                                e.preventDefault();
                                e.stopPropagation();
                                setIsShowingModal(!isShowingModal);
                            },
                            children: "Перезвоните мне"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Nav_Burger_Burger_component__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2142:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _headerPhone_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1589);
/* harmony import */ var _headerPhone_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_headerPhone_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _constants_json_about_firm_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2997);




const HeaderPhone = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_headerPhone_module_scss__WEBPACK_IMPORTED_MODULE_3___default().header_phone),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                href: `tel:${_constants_json_about_firm_json__WEBPACK_IMPORTED_MODULE_2__/* .phone[0] */ .m7[0]}`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: _constants_json_about_firm_json__WEBPACK_IMPORTED_MODULE_2__/* .phoneImg[0] */ .df[0]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        className: (_headerPhone_module_scss__WEBPACK_IMPORTED_MODULE_3___default().phone_img),
                        src: "/images/header/A1-2018.webp",
                        alt: "a1 logo",
                        width: "0",
                        height: "0",
                        sizes: "100vw"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                href: `tel:${_constants_json_about_firm_json__WEBPACK_IMPORTED_MODULE_2__/* .phone[1] */ .m7[1]}`,
                className: (_headerPhone_module_scss__WEBPACK_IMPORTED_MODULE_3___default().phone_mts),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: _constants_json_about_firm_json__WEBPACK_IMPORTED_MODULE_2__/* .phoneImg[1] */ .df[1]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        className: (_headerPhone_module_scss__WEBPACK_IMPORTED_MODULE_3___default().phone_img),
                        src: "/images/header/MTS_Logo_rus_r.png",
                        alt: "mts logo",
                        width: "0",
                        height: "0",
                        sizes: "100vw"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                href: `tel:${_constants_json_about_firm_json__WEBPACK_IMPORTED_MODULE_2__/* .phone[0] */ .m7[0]}`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                    src: "/phone-call.svg",
                    alt: "phone call",
                    width: 30,
                    height: 30,
                    sizes: "100vw"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeaderPhone);


/***/ }),

/***/ 1300:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _logo_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2231);
/* harmony import */ var _logo_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_logo_module_scss__WEBPACK_IMPORTED_MODULE_3__);




const Logo = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_logo_module_scss__WEBPACK_IMPORTED_MODULE_3___default().logo),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
            href: "/",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                src: "/images/logo_new.png",
                alt: "logo",
                width: "0",
                height: "0",
                sizes: "100vw"
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Logo);


/***/ }),

/***/ 2476:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_json_path_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3496);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _burger_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5234);
/* harmony import */ var _burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_burger_module_scss__WEBPACK_IMPORTED_MODULE_6__);







const Burger = ()=>{
    const [burger_class, setBurgerClass] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(classnames__WEBPACK_IMPORTED_MODULE_2___default()((_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().burger_bar), (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().unclicked)));
    const [menu_class, setMenuClass] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(classnames__WEBPACK_IMPORTED_MODULE_2___default()((_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().menu), (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().hidden)));
    const [isMenuClicked, setIsMenuClicked] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const [nav_burger, setNavBurger] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(classnames__WEBPACK_IMPORTED_MODULE_2___default()((_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().nav_burger), (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().hidden)));
    const [showSpoiler, setShowSpoiler] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(Array(5).fill(true));
    const updateMenu = ()=>{
        if (!isMenuClicked) {
            setBurgerClass(classnames__WEBPACK_IMPORTED_MODULE_2___default()((_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().burger_bar), (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().clicked)));
            setMenuClass(classnames__WEBPACK_IMPORTED_MODULE_2___default()((_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().menu), (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().visible)));
            setNavBurger(classnames__WEBPACK_IMPORTED_MODULE_2___default()((_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().nav_burger), (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().visible)));
        } else {
            setBurgerClass(classnames__WEBPACK_IMPORTED_MODULE_2___default()((_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().burger_bar), (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().unclicked)));
            setMenuClass(classnames__WEBPACK_IMPORTED_MODULE_2___default()((_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().menu), (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().hidden)));
            setNavBurger(classnames__WEBPACK_IMPORTED_MODULE_2___default()((_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().nav_burger), (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().hidden)));
        }
        setIsMenuClicked(!isMenuClicked);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().burger_menu),
                onClick: updateMenu,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: burger_class
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: burger_class
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: burger_class
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: menu_class,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(nav_burger),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().first_ul),
                        children: _constants_json_path_json__WEBPACK_IMPORTED_MODULE_1__/* .path.map */ .E.map((el, index)=>{
                            if (el.subelements) {
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().list_elem),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().sub_nav),
                                        onClick: ()=>{
                                            let newData = showSpoiler.map((element, i)=>{
                                                if (i === index) {
                                                    return !element;
                                                } else {
                                                    return element;
                                                }
                                            });
                                            setShowSpoiler(newData);
                                        },
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().sub_header),
                                                children: [
                                                    el.namePage,
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().img), !showSpoiler[index] ? (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().rotateImg) : ""),
                                                        src: "/images/header/small-arrow-black.svg",
                                                        alt: "arrow",
                                                        width: 10,
                                                        height: 10
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().sub_nav_list), showSpoiler[index] ? (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().sub_hidden) : ""),
                                                children: el.subelements.map((elem, ind)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                            href: el.link + elem.subLink,
                                                            className: (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().header_link),
                                                            onClick: updateMenu,
                                                            children: elem.name
                                                        })
                                                    }, ind))
                                            })
                                        ]
                                    })
                                }, index);
                            } else {
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().list_elem),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        href: el.link,
                                        onClick: updateMenu,
                                        className: (_burger_module_scss__WEBPACK_IMPORTED_MODULE_6___default().header_link),
                                        children: el.namePage
                                    })
                                }, index);
                            }
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Burger);


/***/ }),

/***/ 4158:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _nav_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(273);
/* harmony import */ var _nav_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_nav_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _constants_json_path_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3496);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);







const Nav = ()=>{
    const [isShow, setIsShow] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const resetStateShow = ()=>setIsShow("");
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
        className: (_nav_module_scss__WEBPACK_IMPORTED_MODULE_6___default().nav),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
            children: _constants_json_path_json__WEBPACK_IMPORTED_MODULE_2__/* .path.map */ .E.map((el, index)=>{
                if (el.subelements) {
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_nav_module_scss__WEBPACK_IMPORTED_MODULE_6___default().header_sub_link),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    children: [
                                        el.namePage,
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            className: (_nav_module_scss__WEBPACK_IMPORTED_MODULE_6___default().nav_arrow),
                                            src: "/images/header/small-arrow.svg",
                                            alt: "arrow",
                                            width: "10",
                                            height: "10",
                                            sizes: "100vw"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            className: (_nav_module_scss__WEBPACK_IMPORTED_MODULE_6___default().nav_arrow_black),
                                            src: "/images/header/small-arrow-black.svg",
                                            alt: "arrow",
                                            width: "10",
                                            height: "10",
                                            sizes: "100vw"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: classnames__WEBPACK_IMPORTED_MODULE_5___default()((_nav_module_scss__WEBPACK_IMPORTED_MODULE_6___default().addiction_nav), isShow),
                                    onClick: ()=>{
                                        setIsShow((_nav_module_scss__WEBPACK_IMPORTED_MODULE_6___default().hidden));
                                        setTimeout(()=>{
                                            resetStateShow();
                                        }, 0);
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                        children: el.subelements.map((element, index)=>{
                                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                    href: el.link + element.subLink,
                                                    children: element.name
                                                })
                                            }, index);
                                        })
                                    })
                                })
                            ]
                        })
                    }, index);
                } else {
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: el.link,
                            children: el.namePage
                        })
                    }, index);
                }
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Nav);


/***/ }),

/***/ 8862:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Header_Header_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7981);
/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(362);
/* harmony import */ var _layout_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6464);
/* harmony import */ var _layout_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_layout_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _advertise_advertise_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3318);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Header_Header_component__WEBPACK_IMPORTED_MODULE_1__, _advertise_advertise_component__WEBPACK_IMPORTED_MODULE_3__]);
([_Header_Header_component__WEBPACK_IMPORTED_MODULE_1__, _advertise_advertise_component__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const Layout = ({ children  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Header_Header_component__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_layout_module_scss__WEBPACK_IMPORTED_MODULE_4___default().layout_main),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container",
                    children: children
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_advertise_advertise_component__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_footer__WEBPACK_IMPORTED_MODULE_2__/* .Footer */ .$, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3318:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _advertise_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2312);
/* harmony import */ var _advertise_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_advertise_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _constants_json_about_firm_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2997);
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6851);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_modal__WEBPACK_IMPORTED_MODULE_3__]);
_modal__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const Advertise = ()=>{
    const [isShowingModal, setIsShowingModal] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_advertise_module_scss__WEBPACK_IMPORTED_MODULE_5___default().block),
        children: [
            isShowingModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modal__WEBPACK_IMPORTED_MODULE_3__/* .Modal */ .u, {
                isShowingModal: isShowingModal,
                setIsShowingModal: setIsShowingModal,
                typeOfModal: "call"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_advertise_module_scss__WEBPACK_IMPORTED_MODULE_5___default().wrapper),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_advertise_module_scss__WEBPACK_IMPORTED_MODULE_5___default().block_img),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                className: (_advertise_module_scss__WEBPACK_IMPORTED_MODULE_5___default().img_fridge),
                                src: "/images/advertase/fridge.png",
                                width: "0",
                                height: "0",
                                alt: "fridge",
                                sizes: "100vw"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                className: (_advertise_module_scss__WEBPACK_IMPORTED_MODULE_5___default().img_master),
                                src: "/images/advertase/master.png",
                                width: "0",
                                height: "0",
                                alt: "master",
                                sizes: "100vw"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_advertise_module_scss__WEBPACK_IMPORTED_MODULE_5___default().block_info),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                children: "Звоните прямо сейчас"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                children: "Ответим на все вопросы по телефонам"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h4", {
                                className: (_advertise_module_scss__WEBPACK_IMPORTED_MODULE_5___default().info_phone),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: `tel:${_constants_json_about_firm_json__WEBPACK_IMPORTED_MODULE_2__/* .phone[0] */ .m7[0]}`,
                                        children: _constants_json_about_firm_json__WEBPACK_IMPORTED_MODULE_2__/* .phoneImg[0] */ .df[0]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: `tel:${_constants_json_about_firm_json__WEBPACK_IMPORTED_MODULE_2__/* .phone[1] */ .m7[1]}`,
                                        children: _constants_json_about_firm_json__WEBPACK_IMPORTED_MODULE_2__/* .phoneImg[1] */ .df[1]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "btn-yellow",
                                onClick: (e)=>{
                                    e.preventDefault();
                                    e.stopPropagation();
                                    setIsShowingModal(!isShowingModal);
                                },
                                children: "Перезвоните мне"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Advertise);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 362:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "$": () => (/* reexport */ Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/components/footer/footer.module.scss
var footer_module = __webpack_require__(8231);
var footer_module_default = /*#__PURE__*/__webpack_require__.n(footer_module);
;// CONCATENATED MODULE: ./src/constants/json/footer-contacts.json
const footer_contacts_namespaceObject = JSON.parse('{"Jx":{"XV":"Работаем с 10:00 до 22:00 без выходных","Do":"info@r-teh.by"},"Lx":"© 2016-2023 Сервис-Центр «РемТехСервис» Содержимое сайта не является публичной офертой.","uZ":[{"name":"Ремонт","list":[{"name":"Стиральные машины","link":"/repair-washer"},{"name":"Посудомоечные машины","link":"/repair-dishwasher"},{"name":"Варочные панели","link":"/repair-hob"},{"name":"Электроплиты","link":"/repair-stove"},{"name":"Духовые шкафы","link":"/repair-oven"},{"name":"Сушильные машины","link":"/repair-dryer"}]},{"name":"Установка","list":[{"name":"Стиральные машины","link":"/install-washer"},{"name":"Посудомоечные машины","link":"/install-dishwasher"}]},{"name":"Информация","list":[{"name":"Цены","link":"/price"},{"name":"Вопрос-ответ","link":"/faq"},{"name":"Отзывы","link":"/reviews"},{"name":"Гарантийный случай","link":"/guaranty"},{"name":"Контакты","link":"/contacts"}]}]}');
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/assets/svg/clock-icon.svg
/* harmony default export */ const clock_icon = ({"src":"/_next/static/media/clock-icon.8c6fae78.svg","height":238,"width":238,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./src/assets/svg/ringing-phone-outline-icon.svg
/* harmony default export */ const ringing_phone_outline_icon = ({"src":"/_next/static/media/ringing-phone-outline-icon.cbdc3013.svg","height":512,"width":501,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./src/assets/svg/email-icon.svg
/* harmony default export */ const email_icon = ({"src":"/_next/static/media/email-icon.5a8c62c4.svg","height":89,"width":123,"blurWidth":0,"blurHeight":0});
// EXTERNAL MODULE: ./src/constants/json/about-firm.json
var about_firm = __webpack_require__(2997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./src/components/footer/services/services.module.scss
var services_module = __webpack_require__(7696);
var services_module_default = /*#__PURE__*/__webpack_require__.n(services_module);
;// CONCATENATED MODULE: ./public/images/services/icon_spoiler_white.svg
/* harmony default export */ const icon_spoiler_white = ({"src":"/_next/static/media/icon_spoiler_white.a96f35a0.svg","height":7,"width":12,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./src/components/footer/services/services.tsx







const Services = ()=>{
    const [showSpoiler, setShowSpoiler] = (0,external_react_.useState)(Array(footer_contacts_namespaceObject.uZ.length).fill(false));
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: external_classnames_default()((services_module_default()).service, (services_module_default()).service_desktop),
                children: footer_contacts_namespaceObject.uZ.map((el, ind)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: (services_module_default()).service_ul,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (services_module_default()).service_name,
                                children: el.name
                            }),
                            el.list.map((service, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: (services_module_default()).service_li,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: service.link,
                                        children: service.name
                                    })
                                }, `service-${index}`))
                        ]
                    }, `service-head-${ind}`))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: external_classnames_default()((services_module_default()).service, (services_module_default()).service_mobile),
                children: footer_contacts_namespaceObject.uZ.map((el, ind)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: (services_module_default()).service_ul,
                        onClick: (e)=>{
                            if (e.target.classList.contains((services_module_default()).service_name)) {
                                e.preventDefault();
                                e.stopPropagation();
                                setShowSpoiler(showSpoiler.map((element, i)=>i === ind ? !element : element));
                            }
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: (services_module_default()).service_name,
                                children: [
                                    el.name,
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: icon_spoiler_white,
                                            alt: "spoiler"
                                        })
                                    })
                                ]
                            }),
                            showSpoiler[ind] && el.list.map((service, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: (services_module_default()).service_li,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: service.link,
                                        children: service.name
                                    })
                                }, `service-${index}`))
                        ]
                    }, `service-head-${ind}`))
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/components/footer/services/index.ts


;// CONCATENATED MODULE: ./src/components/footer/footer.tsx










const Footer = ()=>/*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: (footer_module_default()).footer,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (footer_module_default()).firstblock,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (footer_module_default()).contacts,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (footer_module_default()).contacts_container,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: clock_icon,
                                        alt: "work time",
                                        height: 24,
                                        width: 24,
                                        className: (footer_module_default()).icon
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: footer_contacts_namespaceObject.Jx.XV
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (footer_module_default()).contacts_container,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: ringing_phone_outline_icon,
                                        alt: "phone number",
                                        height: 24,
                                        width: 24,
                                        className: (footer_module_default()).icon
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (footer_module_default()).phones,
                                        children: about_firm/* phoneImg.map */.df.map((el, ind)=>/*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: `tel:${about_firm/* phone */.m7[ind]}`,
                                                    children: el
                                                })
                                            }, ind))
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (footer_module_default()).contacts_container,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: email_icon,
                                        alt: "email",
                                        height: 24,
                                        width: 24,
                                        className: (footer_module_default()).icon
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: `mailto:${footer_contacts_namespaceObject.Jx.Do}`,
                                        children: footer_contacts_namespaceObject.Jx.Do
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (footer_module_default()).secondblock,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (footer_module_default()).customer,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: footer_contacts_namespaceObject.Lx
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: `${about_firm/* officialName */.X4}  ${about_firm/* UNP */.Ys}`
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Services, {})
                    ]
                })
            ]
        })
    });

;// CONCATENATED MODULE: ./src/components/footer/index.ts



/***/ }),

/***/ 9212:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8862);
/* harmony import */ var _styles_globals_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6961);
/* harmony import */ var _styles_globals_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_scss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_gtm_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7935);
/* harmony import */ var react_gtm_module__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_gtm_module__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__]);
_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function App({ Component , pageProps  }) {
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        react_gtm_module__WEBPACK_IMPORTED_MODULE_5___default().initialize({
            gtmId: "GTM-TF3HTVB"
        });
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "РемТехСервис"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "keywords",
                        content: "ремтехсервис ремонт техники, ремонт стиральные машины, ремонт посудомоечные машины, ремонт варочные панели, ремонт электроплиты, ремонт духовные шкафы,ремонт сушильные машины, УНП 193683932, ООО Кронс Компани"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                    ...pageProps
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6961:
/***/ (() => {



/***/ }),

/***/ 9003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 7935:
/***/ ((module) => {

"use strict";
module.exports = require("react-gtm-module");

/***/ }),

/***/ 7597:
/***/ ((module) => {

"use strict";
module.exports = require("react-text-mask");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5641:
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ }),

/***/ 2997:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"X4":"ООО \\"Кронс Компани\\"","Ys":"УНП 193683932","Do":"info@r-teh.by","m7":[80336380090,80336380020],"df":["+375 (33) 638-00-90","+375 (33) 638-00-20"],"XV":{"B":"10:00","u":"22:00"}}');

/***/ }),

/***/ 3496:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"E":[{"namePage":"Ремонт","link":"/repair-","subelements":[{"name":"Стиральные машины","subLink":"washer"},{"name":"Посудомоечные машины","subLink":"dishwasher"},{"name":"Варочные панели","subLink":"hob"},{"name":"Электроплиты","subLink":"stove"},{"name":"Духовые шкафы","subLink":"oven"},{"name":"Сушильные машины","subLink":"dryer"}]},{"link":"/install-","namePage":"Установка","subelements":[{"name":"Стиральные машины","subLink":"washer"},{"name":"Посудомоечные машины","subLink":"dishwasher"}]},{"link":"/price","namePage":"Цены"},{"link":"/faq","namePage":"Вопрос-ответ"},{"link":"/reviews","namePage":"Отзывы"},{"link":"/guaranty","namePage":"Гарантийный случай"},{"link":"/contacts","namePage":"Контакты"}]}');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [636,675,664,851], () => (__webpack_exec__(9212)));
module.exports = __webpack_exports__;

})();