"use strict";
exports.id = 367;
exports.ids = [367];
exports.modules = {

/***/ 5367:
/***/ ((module) => {

module.exports = JSON.parse('{"u":[{"p":[{"name":"Стиральные машины","image":"images/services/icon_washer.svg","link":"/repair/washer","filterName":"washer"},{"name":"Посудомоечные машины","image":"images/services/icon_dishwasher.svg","link":"/repair/dishwasher","filterName":"dishwasher"},{"name":"Варочные панели","image":"images/services/icon_cook.svg","link":"/repair/hob","filterName":"hob"},{"name":"Электроплиты","image":"images/services/icon_electric_cook.svg","link":"/repair/stove","filterName":"stove"},{"name":"Духовые шкафы","image":"images/services/icon_cooker.svg","link":"/repair/oven","filterName":"oven"},{"name":"Сушильные машины","image":"images/services/icon_dry_machine.svg","link":"/repair/dryer","filterName":"dryer"}]}]}');

/***/ })

};
;