exports.id = 851;
exports.ids = [851];
exports.modules = {

/***/ 1518:
/***/ ((module) => {

// Exports
module.exports = {
	"section": "modal_section__ysrtb",
	"wrapper": "modal_wrapper__vGMV1",
	"close_icon": "modal_close_icon__5le52",
	"modal": "modal_modal__xuQFK",
	"title": "modal_title__jE7kf",
	"gratitude": "modal_gratitude__rY4LN",
	"btn": "modal_btn__4xA4j",
	"form_invalid": "modal_form_invalid__8awwt",
	"textarea": "modal_textarea__DcoR4",
	"invalid": "modal_invalid___w0wk",
	"error": "modal_error__H_rK0",
	"input": "modal_input__b2kpC",
	"label": "modal_label__RF_Ob",
	"label_area": "modal_label_area__i1_QY",
	"placeholder": "modal_placeholder__zVPFh",
	"loader": "modal_loader__UdHxX",
	"loading": "modal_loading__WC80Z"
};


/***/ }),

/***/ 5171:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Icon_close.a4bedc14.svg","height":16,"width":16,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 9942:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Loader.516f44bd.svg","height":68,"width":70,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 6851:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "u": () => (/* reexport safe */ _modal__WEBPACK_IMPORTED_MODULE_0__.u)
/* harmony export */ });
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8715);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_modal__WEBPACK_IMPORTED_MODULE_0__]);
_modal__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8715:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "u": () => (/* binding */ Modal)
/* harmony export */ });
/* unused harmony export useTypeOfModal */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5641);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _public_images_modal_Icon_close_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5171);
/* harmony import */ var _public_images_modal_Loader_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9942);
/* harmony import */ var _modal_module_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1518);
/* harmony import */ var _modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_modal_module_scss__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_text_mask__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7597);
/* harmony import */ var react_text_mask__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_text_mask__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _hooks_scroll_lock__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5036);
/* harmony import */ var _constant_regex__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1332);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_2__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











// export const useScrollLock = () => {
//     const lockScroll = useCallback(() => {
//         document.body.style.overflow = 'hidden';
//     }, [])
//     const unlockScroll = useCallback(() => {
//         document.body.style.overflow = '';
//     }, []);
//     return {
//         lockScroll,
//         unlockScroll
//     };
// }
const useTypeOfModal = (type)=>{
    switch(true){
        case type === "review":
            return {
                isReview: true,
                isRequest: false,
                isWarranty: false,
                isCall: false
            };
        case type === "request":
            return {
                isReview: false,
                isRequest: true,
                isWarranty: false,
                isCall: false
            };
        case type === "warranty":
            return {
                isReview: false,
                isRequest: false,
                isWarranty: true,
                isCall: false
            };
        case type === "call":
            return {
                isReview: false,
                isRequest: false,
                isWarranty: false,
                isCall: true
            };
        default:
            return {
                isReview: false,
                isRequest: false,
                isWarranty: false,
                isCall: false
            };
    }
};
const Modal = ({ isShowingModal , setIsShowingModal , typeOfModal  })=>{
    const modalRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const { register , handleSubmit , control , formState: { errors , isValid  }  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_2__.useForm)({
        mode: "all"
    });
    const { isReview , isRequest , isWarranty , isCall  } = useTypeOfModal(typeOfModal);
    const [isSuccess, setIsSuccess] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [isError, setIsError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { lockScroll , unlockScroll  } = (0,_hooks_scroll_lock__WEBPACK_IMPORTED_MODULE_8__/* .useScrollLock */ .P)();
    const onSubmit = async (data)=>{
        setIsLoading(true);
        const requestOptions = {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                TITLE: data.message
            })
        };
        fetch(`https://b24-jk9jbm.bitrix24.by/rest/1/pv44ctw5ojrpgsrl/crm.lead.add.json?`, requestOptions).then(()=>setIsSuccess(true)).catch(()=>setIsError(true));
    };
    const closeHandler = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        setIsShowingModal(false);
        unlockScroll();
    }, [
        setIsShowingModal,
        unlockScroll
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useLayoutEffect)(()=>{
        const closeModal = (e)=>{
            if (!modalRef.current?.contains(e.target) && isShowingModal) {
                closeHandler();
            }
        };
        document.body.addEventListener("click", closeModal);
        return ()=>document.body.removeEventListener("click", closeModal);
    }, [
        isShowingModal,
        setIsShowingModal,
        closeHandler
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isShowingModal) {
            lockScroll();
        } else {
            unlockScroll();
        }
    }, [
        isShowingModal,
        lockScroll,
        unlockScroll
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().section),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().wrapper),
            ref: modalRef,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    type: "button",
                    className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().close_icon),
                    onClick: ()=>closeHandler(),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                        src: _public_images_modal_Icon_close_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                        alt: "close icon"
                    })
                }),
                isSuccess && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().modal),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().title),
                            children: isReview ? "Благодарим за отзыв" : "Благодарим за обращение"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().gratitude),
                            children: isReview ? "Нам важно Ваше мнение." : "Мы рассмотрим Ваше обращение в самые кратчайшие сроки."
                        })
                    ]
                }),
                isError && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().modal),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().title),
                        children: "Что-то пошло не так. Попробуйте позже"
                    })
                }),
                !isSuccess && !isError && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                    className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().modal),
                    onSubmit: handleSubmit(onSubmit),
                    children: [
                        isReview && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().title),
                            children: "Оставить отзыв"
                        }),
                        isRequest && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().title),
                            children: "Оставить заявку"
                        }),
                        isWarranty && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().title),
                            children: "Обратиться по гарантии"
                        }),
                        isCall && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                            className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().title),
                            children: "Заказать обратный звонок"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                            className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().label),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()((_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().input), {
                                        [(_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().invalid)]: errors.name
                                    }),
                                    placeholder: "Фамилия и имя",
                                    ...register("name", {
                                        required: {
                                            value: true,
                                            message: "Поле не может быть пустым"
                                        },
                                        pattern: {
                                            value: /^[а-яА-Я\s]*$/i,
                                            message: "Используйте кириллицу"
                                        }
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().placeholder),
                                    children: "Фамилия и имя"
                                }),
                                errors.name && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().error),
                                    children: errors.name.message
                                })
                            ]
                        }),
                        (isRequest || isWarranty) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                            className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().label),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()((_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().input), {
                                        [(_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().invalid)]: errors.address
                                    }),
                                    placeholder: "Адрес",
                                    ...register("address", {
                                        required: {
                                            value: true,
                                            message: "Поле не может быть пустым"
                                        },
                                        pattern: {
                                            value: /[^a-zA-z]/,
                                            message: "Используйте кириллицу"
                                        }
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().placeholder),
                                    children: "Адрес"
                                }),
                                errors.address && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().error),
                                    children: errors.address.message
                                })
                            ]
                        }),
                        (isRequest || isWarranty || isCall) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_2__.Controller, {
                            control: control,
                            name: "phone",
                            rules: {
                                required: "Поле не может быть пустым",
                                validate: {
                                    hasXsymbols: (value)=>value.match(_constant_regex__WEBPACK_IMPORTED_MODULE_9__/* .PhoneMasks.placeholderChar */ .i.placeholderChar) === null || "В формате +375 (xx) xxx-xx-xx",
                                    hasWrongCode: (value)=>value.match(_constant_regex__WEBPACK_IMPORTED_MODULE_9__/* .PhoneMasks.codePhoneRegex */ .i.codePhoneRegex) !== null || "Проверьте код оператора"
                                }
                            },
                            render: ({ field  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                    className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().label),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_text_mask__WEBPACK_IMPORTED_MODULE_7___default()), {
                                            name: "phone",
                                            value: field.value,
                                            type: "tel",
                                            inputMode: "tel",
                                            mask: _constant_regex__WEBPACK_IMPORTED_MODULE_9__/* .PhoneMasks.phoneMask */ .i.phoneMask,
                                            placeholderChar: "x",
                                            className: classnames__WEBPACK_IMPORTED_MODULE_3___default()((_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().input), {
                                                [(_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().invalid)]: errors.phone
                                            }),
                                            placeholder: "Номер телефона",
                                            guide: true,
                                            onChange: field.onChange,
                                            onBlur: field.onBlur
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().placeholder),
                                            children: "Номер телефона"
                                        }),
                                        errors.phone && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().error),
                                            children: errors.phone.message
                                        })
                                    ]
                                })
                        }),
                        !isCall && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                            className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().label_area),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()((_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().textarea), {
                                        [(_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().invalid)]: errors.message
                                    }),
                                    placeholder: isReview ? "Опишите Ваше впечатление о проделанной нами работе." : isRequest ? "Опишите возникшую проблему (Вид и модель техники, неисправность)" : isWarranty ? "Опишите Ваш гарантийный случай, с указанием сведений из гарантийного талона" : "",
                                    ...register("message", {
                                        required: {
                                            value: true,
                                            message: "Поле не может быть пустым"
                                        }
                                    })
                                }),
                                errors.message && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().error),
                                    children: errors.message.message
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_3___default()((_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().btn)),
                            disabled: isLoading || !isValid,
                            type: "submit",
                            children: [
                                isLoading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    className: (_modal_module_scss__WEBPACK_IMPORTED_MODULE_10___default().loader),
                                    src: _public_images_modal_Loader_svg__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                                    width: 15,
                                    height: 15,
                                    alt: "loading"
                                }),
                                isReview ? "Оставить отзыв" : isRequest ? "Отправить заявку" : isWarranty ? "Обратиться по гарантии" : isCall ? "Мы перезвоним Вам" : ""
                            ]
                        })
                    ]
                })
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1332:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i": () => (/* binding */ PhoneMasks)
/* harmony export */ });
const PhoneMasks = {
    placeholderChar: /x/,
    codePhoneRegex: /^(\+375 \((29|44|25|33)\)\s)/,
    phoneMask: [
        "+",
        "3",
        "7",
        "5",
        " ",
        "(",
        /[2,3,4]/,
        /[5,9,3,4]/,
        ")",
        " ",
        /\d/,
        /\d/,
        /\d/,
        "-",
        /\d/,
        /\d/,
        "-",
        /\d/,
        /\d/
    ]
};


/***/ }),

/***/ 5036:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ useScrollLock)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const useScrollLock = ()=>{
    const lockScroll = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        document.body.style.overflow = "hidden";
    }, []);
    const unlockScroll = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        document.body.style.overflow = "";
    }, []);
    return {
        lockScroll,
        unlockScroll
    };
};


/***/ })

};
;