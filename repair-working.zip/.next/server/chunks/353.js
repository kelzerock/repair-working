exports.id = 353;
exports.ids = [353];
exports.modules = {

/***/ 5829:
/***/ ((module) => {

// Exports
module.exports = {
	"section": "benefits_section__m9PX1",
	"list_header": "benefits_list_header___lOxz",
	"title": "benefits_title__djxI4",
	"list_ul": "benefits_list_ul__0ov_v",
	"list_li": "benefits_list_li__r9Lge",
	"img": "benefits_img__BCrx3",
	"list_title": "benefits_list_title__H3bKr",
	"list_desc": "benefits_list_desc__v8eJ4",
	"list_hidden": "benefits_list_hidden__pbKrR"
};


/***/ }),

/***/ 3060:
/***/ ((module) => {

// Exports
module.exports = {
	"section": "reviews_section__avxPU",
	"title": "reviews_title__ub5Ia",
	"wrapper": "reviews_wrapper__7NjAI",
	"score_wrapper": "reviews_score_wrapper__j8M_n",
	"score_div": "reviews_score_div__b_B47",
	"score_num": "reviews_score_num__x9SqM",
	"score_text": "reviews_score_text__HLV9q",
	"score_div_desc": "reviews_score_div_desc__xjC6K",
	"feedback_wrapper": "reviews_feedback_wrapper__ozCmw",
	"textarea": "reviews_textarea__us8hA",
	"reviews": "reviews_reviews__sU0dO",
	"btn": "reviews_btn__Ok_Fw",
	"link_btn": "reviews_link_btn__PdCaH"
};


/***/ }),

/***/ 8402:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "f": () => (/* reexport */ Benefits)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./src/components/benefits/benefits.module.scss
var benefits_module = __webpack_require__(5829);
var benefits_module_default = /*#__PURE__*/__webpack_require__.n(benefits_module);
;// CONCATENATED MODULE: ./src/constants/json/benefits.json
const benefits_namespaceObject = JSON.parse('[{"title":"Выезд мастера и диагностика в подарок","desc":"При согласии на ремонт","image":"/images/benefits/icon_benefits_master.svg"},{"title":"Гарантия до 2 лет на работу и запчасти","desc":"","image":"/images/benefits/icon_benefits_warranty.svg"},{"title":"Ремонт в течение суток после вызова","desc":"","image":"/images/benefits/icon_benefits_fast.svg"},{"title":"Оригинальные запчасти,","desc":"Сертифицированные производителями","image":"/images/benefits/icon_benefits_original_parts.svg"},{"title":"Мастера с опытом от 5 лет","desc":"Берем в штат только опытных мастеров","image":"/images/benefits/icon_benefits_quality.svg"},{"title":"Отличный сервис в Минске и Минском районе","desc":"С 2016 г. ремонтируем бытовую технику","image":"/images/benefits/icon_benefits_bigger.svg"}]');
;// CONCATENATED MODULE: ./src/components/benefits/benefits.tsx






const Benefits = ()=>{
    const [isShowing, setIsShowing] = (0,external_react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: external_classnames_default()((benefits_module_default()).section, "container"),
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (benefits_module_default()).list_header,
                onClick: ()=>setIsShowing(!isShowing),
                role: "presentation",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: (benefits_module_default()).title,
                        children: "Преимущества для Вас"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/images/services/icon_spoiler_blue.svg",
                            alt: "spoiler",
                            width: 12,
                            height: 7,
                            className: external_classnames_default()({
                                "rotate": !isShowing
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: external_classnames_default()((benefits_module_default()).list_ul, {
                    [(benefits_module_default()).list_hidden]: isShowing
                }),
                children: benefits_namespaceObject.map((el, ind)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: (benefits_module_default()).list_li,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: el.image,
                                alt: el.title,
                                width: 74,
                                height: 70,
                                className: (benefits_module_default()).img
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: (benefits_module_default()).list_title,
                                children: el.title
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: (benefits_module_default()).list_desc,
                                children: el.desc
                            })
                        ]
                    }, `benefits-${ind}`))
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/components/benefits/index.ts



/***/ }),

/***/ 2067:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* reexport safe */ _reviews__WEBPACK_IMPORTED_MODULE_0__.Z)
/* harmony export */ });
/* harmony import */ var _reviews__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6268);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_reviews__WEBPACK_IMPORTED_MODULE_0__]);
_reviews__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6268:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Reviews)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _reviews_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3060);
/* harmony import */ var _reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_reviews_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _constants_json_reviews_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7600);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6851);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_modal__WEBPACK_IMPORTED_MODULE_5__]);
_modal__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const Reviews = ()=>{
    const [isShowingModal, setIsShowingModal] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default().section), "container"),
        children: [
            isShowingModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modal__WEBPACK_IMPORTED_MODULE_5__/* .Modal */ .u, {
                isShowingModal: isShowingModal,
                setIsShowingModal: setIsShowingModal,
                typeOfModal: "review"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default().wrapper),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default().score_wrapper),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default().score_div),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: (_reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default().score_num),
                                    children: [
                                        _constants_json_reviews_json__WEBPACK_IMPORTED_MODULE_2__/* .total.percent */ .M.aQ,
                                        "%"
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: (_reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default().score_text),
                                    children: "положительных отзывов"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default().feedback_wrapper),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                href: "#",
                                className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("link", (_reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default().link_btn)),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default().btn),
                                    onClick: (e)=>{
                                        e.preventDefault();
                                        e.stopPropagation();
                                        setIsShowingModal(!isShowingModal);
                                    },
                                    children: "Отправить отзыв"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                href: "/reviews",
                                className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("link", (_reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default().link_btn)),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: (_reviews_module_scss__WEBPACK_IMPORTED_MODULE_6___default().btn),
                                    children: "Перейти в раздел"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;