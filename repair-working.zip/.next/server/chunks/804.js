"use strict";
exports.id = 804;
exports.ids = [804];
exports.modules = {

/***/ 2804:
/***/ ((module) => {

module.exports = JSON.parse('{"Jx":{"XV":"Работаем с 10:00 до 22:00 без выходных","m7":["+8 (033) 638 00 90","+8 (033) 638 00 20"],"Do":"info@r-teh.by"},"xs":[{"name":"instagram","image":"/images/black-instagram-icon.svg","link":"#"},{"name":"youtube","image":"/images/youtube-round-line-icon.svg","link":"#"},{"name":"facebook","image":"/images/facebook-round-icon.svg","link":"#"},{"name":"vk","image":"/images/vk-round-line-icon.svg","link":"#"}],"Lx":"© 2016-2023 Сервис-Центр «РемТехСервис» Содержимое сайта не является публичной офертой.","uZ":[{"name":"Ремонт","list":[{"name":"Стиральные машины","link":"/repair/washer"},{"name":"Посудомоечные машины","link":"/repair/dishwasher"},{"name":"Варочные панели","link":"/repair/hob"},{"name":"Электроплиты","link":"/repair/stove"},{"name":"Духовые шкафы","link":"/repair/oven"},{"name":"Сушильные машины","link":"/repair/dryer"}]},{"name":"Установка","list":[{"name":"Стиральные машины","link":"/installation/washer"},{"name":"Посудомоечные машины","link":"/installation/dishwasher"}]},{"name":"Информация","list":[{"name":"Цены","link":"/price"},{"name":"Вопрос-ответ","link":"/faq"},{"name":"Отзывы","link":"/reviews"},{"name":"Гарантийный случай","link":"/guaranty"},{"name":"Контакты","link":"/contacts"}]}]}');

/***/ })

};
;