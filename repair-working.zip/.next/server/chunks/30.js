exports.id = 30;
exports.ids = [30];
exports.modules = {

/***/ 2245:
/***/ ((module) => {

// Exports
module.exports = {
	"block": "repair-break_block__CapxZ",
	"block_ul": "repair-break_block_ul__G3EoP",
	"block_li": "repair-break_block_li__CLykZ",
	"break_btn": "repair-break_break_btn__pSbA5",
	"li_info": "repair-break_li_info__71ZYa",
	"block_li_img": "repair-break_block_li_img__RkwAw",
	"item_info": "repair-break_item_info__wKv__"
};


/***/ }),

/***/ 6900:
/***/ ((module) => {

// Exports
module.exports = {
	"calculating": "repair-calculating_calculating__OKBgY",
	"calculating_container": "repair-calculating_calculating_container___QjEc",
	"calculation_info": "repair-calculating_calculation_info__A5ZlE"
};


/***/ }),

/***/ 5724:
/***/ ((module) => {

// Exports
module.exports = {
	"repair_info": "repair-info_repair_info__l2S0g",
	"repair_info_white": "repair-info_repair_info_white___DbuA",
	"repair_info_blue": "repair-info_repair_info_blue__QxHAF",
	"title": "repair-info_title__uLHAi",
	"info": "repair-info_info__t9gf1",
	"minorTitle": "repair-info_minorTitle__3_CL6",
	"text": "repair-info_text__fTqNp"
};


/***/ }),

/***/ 7499:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _repair_break_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2245);
/* harmony import */ var _repair_break_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_repair_break_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _constants_json_repair_break_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1351);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6851);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_modal__WEBPACK_IMPORTED_MODULE_4__]);
_components_modal__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const jsonInfo = _constants_json_repair_break_json__WEBPACK_IMPORTED_MODULE_1__;
const RepairBreak = ({ filter  })=>{
    const [isShowingModal, setIsShowingModal] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_repair_break_module_scss__WEBPACK_IMPORTED_MODULE_6___default().block),
        children: [
            isShowingModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_modal__WEBPACK_IMPORTED_MODULE_4__/* .Modal */ .u, {
                isShowingModal: isShowingModal,
                setIsShowingModal: setIsShowingModal,
                typeOfModal: "request"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                children: "Стоимость ремонта частых поломок"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: (_repair_break_module_scss__WEBPACK_IMPORTED_MODULE_6___default().block_ul),
                children: jsonInfo[filter].data.map((el, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        className: (_repair_break_module_scss__WEBPACK_IMPORTED_MODULE_6___default().block_li),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_repair_break_module_scss__WEBPACK_IMPORTED_MODULE_6___default().li_info),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        className: (_repair_break_module_scss__WEBPACK_IMPORTED_MODULE_6___default().block_li_img),
                                        src: el.img,
                                        alt: el.imgAlt,
                                        width: "0",
                                        height: "0",
                                        sizes: "100vw"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_repair_break_module_scss__WEBPACK_IMPORTED_MODULE_6___default().item_info),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                children: el.title
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                children: el.info.map((elem, ind)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                                src: "/images/repair/check-svgrepo-com.svg",
                                                                alt: "check",
                                                                width: 20,
                                                                height: 20
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                children: elem
                                                            })
                                                        ]
                                                    }, ind))
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("btn-yellow", (_repair_break_module_scss__WEBPACK_IMPORTED_MODULE_6___default().break_btn)),
                                onClick: (e)=>{
                                    e.preventDefault();
                                    e.stopPropagation();
                                    setIsShowingModal(!isShowingModal);
                                },
                                children: [
                                    "от ",
                                    el.price,
                                    " руб."
                                ]
                            })
                        ]
                    }, index))
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RepairBreak);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7496:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _repair_calculating_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6900);
/* harmony import */ var _repair_calculating_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_repair_calculating_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _constants_json_repaire_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1151);
/* harmony import */ var _components_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6851);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_modal__WEBPACK_IMPORTED_MODULE_3__]);
_components_modal__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const RepairCalculating = ()=>{
    const [isShowingModal, setIsShowingModal] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const { calculation  } = _constants_json_repaire_json__WEBPACK_IMPORTED_MODULE_2__;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_repair_calculating_module_scss__WEBPACK_IMPORTED_MODULE_5___default().calculating),
        children: [
            isShowingModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_modal__WEBPACK_IMPORTED_MODULE_3__/* .Modal */ .u, {
                isShowingModal: isShowingModal,
                setIsShowingModal: setIsShowingModal,
                typeOfModal: "request"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_repair_calculating_module_scss__WEBPACK_IMPORTED_MODULE_5___default().calculating_container),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        src: "/images/accountant.webp",
                        alt: "accountant",
                        width: "0",
                        height: "0",
                        sizes: "100vw"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_repair_calculating_module_scss__WEBPACK_IMPORTED_MODULE_5___default().calculation_info),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                children: calculation.title
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: calculation.text
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "btn-yellow ",
                                onClick: (e)=>{
                                    e.preventDefault();
                                    e.stopPropagation();
                                    setIsShowingModal(!isShowingModal);
                                },
                                children: "Рассчитать ремонт"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RepairCalculating);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7816:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _repair_info_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5724);
/* harmony import */ var _repair_info_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_repair_info_module_scss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _constants_json_repaire_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1151);



const RepairInfo = ()=>{
    const { priceInformation  } = _constants_json_repaire_json__WEBPACK_IMPORTED_MODULE_1__;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_repair_info_module_scss__WEBPACK_IMPORTED_MODULE_2___default().repair_info),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_repair_info_module_scss__WEBPACK_IMPORTED_MODULE_2___default().repair_info_white),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: (_repair_info_module_scss__WEBPACK_IMPORTED_MODULE_2___default().title),
                        children: priceInformation.title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: (_repair_info_module_scss__WEBPACK_IMPORTED_MODULE_2___default().info),
                        children: priceInformation.info
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_repair_info_module_scss__WEBPACK_IMPORTED_MODULE_2___default().repair_info_blue),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                        className: (_repair_info_module_scss__WEBPACK_IMPORTED_MODULE_2___default().minorTitle),
                        children: priceInformation.minorTitle
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: (_repair_info_module_scss__WEBPACK_IMPORTED_MODULE_2___default().text),
                        children: priceInformation.text
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RepairInfo);


/***/ }),

/***/ 1351:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"washer":{"header":"washer","data":[{"img":"/images/repair/washer/ne-slivaet.png","imgAlt":"washer ne slivaet","title":"не сливает","info":["Замена сливного насоса","Ремонт прессостата"],"price":130},{"img":"/images/repair/washer/ne-otjimaet.png","imgAlt":"washer ne otjimaet","title":"не отжимает","info":["Замена угольных щеток","Прошивка электронного модуля"],"price":130},{"img":"/images/repair/washer/ne-greet-water.png","imgAlt":"washer ne greet","title":"не греет воду","info":["Замена ТЭН (нагревателя воды)","Ремонт блока управления"],"price":120},{"img":"/images/repair/washer/ne-vkl.png","imgAlt":"washer ne vkl","title":"не включается","info":["Прошивка платы управления","Замена сетевого фильтра"],"price":150},{"img":"/images/repair/washer/prigaet.png","imgAlt":"washer prigaet","title":"прыгает","info":["Замена амортизаторов","Замена подшипников"],"price":140},{"img":"/images/repair/washer/shumit.png","imgAlt":"washer shumit","title":"шумит","info":["Замена подшипников","Удаление инородного предмета"],"price":80},{"img":"/images/repair/washer/ne-nabiraet.png","imgAlt":"washer ne nabiraet","title":"не набирает воду","info":["Устранение засора","Замена КЭН или прессостата"],"price":60},{"img":"/images/repair/washer/ne-otkriv.png","imgAlt":"washer ne otkriv","title":"не открывается","info":["Замена УБЛ (устройство блокировки люка)","Ремонт проводки"],"price":100},{"img":"/images/repair/washer/migaut.png","imgAlt":"washer migaut","title":"мигают индикаторы","info":["Ремонт блока управления","Сброс прошивки"],"price":130}]},"dishwasher":{"header":"dishwasher","data":[{"img":"/images/repair/dishwasher/ne-moet.png","imgAlt":"dishwasher ne moet","title":"не моет","info":["Замена циркуляционного насоса","Замена модуля управления"],"price":140},{"img":"/images/repair/dishwasher/ne-sliv.png","imgAlt":"dishwasher ne slivaet","title":"не сливает","info":["Замена сливного насоса","Ремонт или замена прессостата"],"price":130},{"img":"/images/repair/dishwasher/ne-nabiraet.png","imgAlt":"dishwasher ne nabiraet","title":"не набирает","info":["Замена впускного клапана","Ремонт или замена прессостата"],"price":120},{"img":"/images/repair/dishwasher/ne-vkl.png","imgAlt":"dishwasher ne vkluchaetsia","title":"не включается","info":["Замена модуля управления","Кнопка включения"],"price":150},{"img":"/images/repair/dishwasher/oshibka.png","imgAlt":"dishwasher oshibka ","title":"горит ошибка","info":["Ремонт модуля управления","Замена сливного насоса"],"price":70},{"img":"/images/repair/dishwasher/ploho-moet.png","imgAlt":"dishwasher ploho moet","title":"плохо моет","info":["Замена разбрызгивателя","Замена ТЭН (нагревателя воды)"],"price":120},{"img":"/images/repair/dishwasher/ne-greet.png","imgAlt":"dishwasher ne greet","title":"не греет","info":["Замена термодатчика"],"price":120},{"img":"/images/repair/dishwasher/techet.png","imgAlt":"dishwasher techet","title":"течёт","info":["Замена уплотнителя дверцы","Замена патрубка"],"price":50},{"img":"/images/repair/dishwasher/migaut.png","imgAlt":"dishwasher migaut","title":"мигают индикаторы","info":["Замена модуля управления","Замена сливного насоса"],"price":130}]},"oven":{"header":"oven","data":[{"img":"/images/repair/oven/ne-vkluchaetsya.png","imgAlt":"oven ne vkluchaetsia","title":"не включается","info":["Ремонт модуля управления","Замена переключателя режимов"],"price":130},{"img":"/images/repair/oven/oshibka.png","imgAlt":"oven oshibka","title":"выдает ошибку","info":["Замена ТЭН","Ремонт силового модуля"],"price":120},{"img":"/images/repair/oven/sama-otkluchaetsya.png","imgAlt":"oven otkluchaetsia","title":"отключается сам","info":["Ремонт силового модуля","Замена ТЭН"],"price":120},{"img":"/images/repair/oven/ne-greet.png","imgAlt":"oven ne greet","title":"не греет","info":["Замена нагревателя","Замена переключателя режимов"],"price":70},{"img":"/images/repair/oven/ne-zakryvaetsya.png","imgAlt":"oven ne zakrivaetsia","title":"не закрывается","info":["Замена уплотнителя","Замена замка дверцы"],"price":120},{"img":"/images/repair/oven/ne-propekaet.png","imgAlt":"oven ne propekaet","title":"не пропекает","info":["Замена ТЭН","Замена вентилятора"],"price":200}]},"stove":{"header":"stove","data":[{"img":"/images/repair/stove/ne-rab-duhovka.png","imgAlt":"stove","title":"не работает духовка","info":["Замена ТЭНа духового шкафа","Замена переключателя мощности духовки"],"price":120},{"img":"/images/repair/stove/ne-rab-konforka.png","imgAlt":"stove","title":"не работает конфорка","info":["Замена конфорки","Замена регулятора мощности конфорки"],"price":140},{"img":"/images/repair/stove/ne-vkl.png","imgAlt":"stove","title":"не включается","info":["Ремонт блока управления","Замена платы сенсора управления"],"price":120},{"img":"/images/repair/stove/oshibka.png","imgAlt":"stove","title":"выдает ошибку","info":["Ремонт модуля управления","Замена конфорки"],"price":140},{"img":"/images/repair/stove/vybivaet.png","imgAlt":"stove","title":"выбивает пробки","info":["Замена конфорки","Ремонт модуля управления"],"price":140},{"img":"/images/repair/stove/otkluchaetsya.png","imgAlt":"stove","title":"отключается сама","info":["Замена регулятора мощности конфорки","Замена силового модуля управления"],"price":130},{"img":"/images/repair/stove/ne-greet.png","imgAlt":"stove","title":"не греет","info":["Замена конфорки","Замена регулятора мощности конфорки"],"price":130}]},"hob":{"header":"hob","data":[{"img":"/images/repair/hob/ne-vkl.png","imgAlt":"hob","title":"не включается","info":["Ремонт силового модуля","Замена термопредохранителя"],"price":130},{"img":"/images/repair/hob/oshibka.png","imgAlt":"hob","title":"выдает ошибку","info":["Ремонт силового модуля","Замена платы сенсора"],"price":130},{"img":"/images/repair/hob/ne-otkluchaet.png","imgAlt":"hob","title":"не отключается","info":["Ремонт силового модуля","Замена регулятора мощности конфорки"],"price":140},{"img":"/images/repair/hob/ne-rab-konforka.png","imgAlt":"hob","title":"не работает конфорка","info":["Замена конфорки","Ремонт силового модуля"],"price":130},{"img":"/images/repair/hob/ne-greet.png","imgAlt":"hob","title":"не греет","info":["Ремонт силового модуля","Замена конфорки"],"price":130},{"img":"/images/repair/hob/sensor.png","imgAlt":"hob","title":"не работает сенсор","info":["Замена платы сенсора","Замена термопредохранителя"],"price":100},{"img":"/images/repair/hob/vybivaet.png","imgAlt":"hob","title":"выбивает пробки","info":["Замена силового модуля","Замена шнура"],"price":100}]},"dryer":{"header":"dryer","data":[{"img":"/images/repair/dryer/ne-greet-water.png","imgAlt":"dryer","title":"не сушит белье","info":["Замена ТЭН","Замена датчика температуры"],"price":120},{"img":"/images/repair/dryer/oshibka.png","imgAlt":"dryer","title":"выдает ошибку","info":["Замена ТЭН","Ремонт модуля управления"],"price":150},{"img":"/images/repair/dryer/ne-vkl.png","imgAlt":"dryer","title":"не включается","info":["Ремонт блока управления","Замена пускового конденсатора"],"price":130},{"img":"/images/repair/dryer/ne-otkriv.png","imgAlt":"dryer","title":"не открывается","info":["Замена замка","Ремонт платы управления"],"price":100},{"img":"/images/repair/dryer/ne-krutit-baraban.png","imgAlt":"dryer","title":"не крутит барабан","info":["Замена ремня","Замена щеток мотора"],"price":140},{"img":"/images/repair/dryer/shumit.png","imgAlt":"dryer","title":"шумит","info":["Замена подшипников","Замена роликов"],"price":250},{"img":"/images/repair/dryer/techet.png","imgAlt":"dryer","title":"течёт","info":["Замена сливного насоса","Замена патрубка"],"price":70},{"img":"/images/repair/dryer/ne-zakruvaetsa.png","imgAlt":"dryer","title":"не закрывается","info":["Замена УБЛ","Ремонт блока управления"],"price":140},{"img":"/images/repair/dryer/migaut.png","imgAlt":"dryer","title":"мигают индикаторы","info":["Замена ТЭН","Ремонт блока управления"],"price":120}]}}');

/***/ }),

/***/ 1151:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"fridge":{"title":"РЕМОНТ ХОЛОДИЛЬНИКОВ НА ДОМУ","info":"Мастерская оказывает услуги по ремонту холодильников. Мастер сервисного центра приедет в удобное для вас время и отремонтирует холодильник прямо у вас дома с гарантией до 2-х лет. Ремонт осуществляется в течение 24 часов с момента обращения или в день, удобный для вас.","advantage":"Преимущества для вас","breakeTitle":"Цены на частые поломки","breake":[{"title":"не отключается","imgPath":"#","info":["Замена термостата","Ремонт модуля управления"],"price":900},{"title":"Плохо морозит","imgPath":"#","info":["Замена фреона","Устранение засора"],"price":900},{"title":"Течет","imgPath":"#","info":["Прочистка дренажного отверстия","Замена термостата","Замена мотора"],"price":900},{"title":"Не работает холодильная камера","imgPath":"","info":["Замена термостата","Замена мотора-компрессора"],"price":900},{"title":"Лёд в морозилке","imgPath":"","info":["Замена фреона","Замена датчика температуры"],"price":900},{"title":"Не морозит морозилка","imgPath":"","info":["Замена фреона","Замена терморегулятора"],"price":900},{"title":"Холодильник не закрывается","imgPath":"","info":["Ремонт петель","Замена уплотнителя"],"price":900},{"title":"Холодильник гудит","imgPath":"","info":["Замена вентелятора","Замена фреона"],"price":900},{"title":"Лёд в холодильной камере","imgPath":"","info":["Ремонт Ноу Фрост","Замена терморегулятора"],"price":900}],"priceList":"Прайс-лист на услуги","priceListInfo":"Точная стоимость ремонта холодильника зависит от ее модели и вида неисправности. Мастеру необходимо выполнить диагностику, прежде чем рассчитать цену. Вот расценки на наши услуги. Цены в таблице только за ремонтные работы, запчасти и комплектующие оплачиваются дополнительно."},"repair":[{"washer":{"first":[]}}],"title-block":{"washer":{"title":"РЕМОНТ СТИРАЛЬНЫХ МАШИН НА ДОМУ","info":"Если ваша стиральная машина вышла из строя, сервисный центр \\"РемТехСервис\\" оперативно устранит неисправность. Ремонт осуществляется на дому специалистами со стажем не менее 5 лет. Другие - просто у нас не работают. Мастер отремонтирует вашу машинку в течение 24-х часов с момента обращения или в любой другой день, который удобен для вас. После ремонта вам будет выдана квитанция с гарантийными обязательствами сроком до 2 лет.","image":"/images/repair/washer-repair.jpg","imageAlt":"washer"},"dishwasher":{"title":"РЕМОНТ ПОСУДОМОЕЧНЫХ МАШИН","info":"Сервисный центр \\"РемТехСервис\\" осуществляет ремонт посудомоечных машин на дому. Мастер приедет в течение 24 часов после вашего обращения, либо в выбранный вами день, точно установит причину неисправности и с вашего согласия устранит её. На все работы по ремонту и новые установленные запчасти предоставляется гарантия на срок до 2 лет.","image":"/images/repair/dishwasher-repair.jpg","imageAlt":"dishwasher"},"dryer":{"title":"РЕМОНТ СУШИЛЬНЫХ МАШИН","info":"Ремонтируем барабанные сушильные машины и сушильные шкафы на дому. Только фирменные запчасти, опытные мастера, гарантия до 24 месяцев. Удобный и быстрый сервис. Обслуживаем технику дома у клиента. У вас коттедж или загородный дом в области? — Обращайтесь! Ремонт в день вызова, если заявка подана до обеда. По вечерней заявке мастер приедет на следующий день. Хотите выбрать другую дату? Назовите её диспетчеру или напишите в форме заказа. Фирменный ремонт за 1 визит! Мастер выполняет всю работу за один приезд, и вы получаете работающую сушилку через 1-2 часа. В редких случаях при сложной поломке модуля управления, ремонт проходит в два этапа: модуль демонтируется и вывозится в мастерскую, затем, через 1-2 дня исправный блок управления возвращается обратно.","image":"/images/repair/dryer-repair.jpeg","imageAlt":"dryer"},"hob":{"title":"РЕМОНТ ВАРОЧНЫХ ПОВЕРХНОСТЕЙ","info":"Мастерская \\"РемТехСервис\\" оказывает услуги по ремонту варочных поверхностей. Устраняем неполадки в электрических панелях любого бренда и устройства: индукционных, обычных электрических, комбинированных. Приезжаем на вызов в течение 24 часов после обращения со всеми необходимыми запчастями и оборудованием и ремонтируем варку прямо при вас. Часто ремонт варочных панелей невозможно провести на дому, и необходимо технику забирать в сервисный центр. После ремонта выписываем гарантийный чек-талон сроком до 1 года.","image":"/images/repair/hob-repair.jpg","imageAlt":"hob"},"oven":{"title":"РЕМОНТ ДУХОВОК","info":"Ремонтируем электрические и комбинированные духовки, как встраиваемого типа, так и в составе плит. Выезжаем на вызов в тот же день или на следующий. Необходимые запчасти и оборудование берём с собой. После устранения неисправности выписываем официальный чек с гарантией на работы до 2 лет, на заменённые детали до 1 года.","image":"/images/repair/oven-repair.jpeg","imageAlt":"oven"},"stove":{"title":"РЕМОНТ ЭЛЕКТРИЧЕСКИХ ПЛИТ НА ДОМУ","info":"Сервисный центр - срочная помощь для электрических плит! Ремонтируем стальные и стеклокерамические кухонные элетроплиты всех брендов с любым типом конфорок. Приезжаем на вызов быстро: в тот же день или на следующий после вашего звонка со всем необходимым оборудованием. Используем только фирменные запчасти. После ремонта выдаём официальную квитанцию с гарантийными обязательствами до 1 года.","image":"/images/repair/stove-repair.jpeg","imageAlt":"stove"}},"calculation":{"title":"Узнайте, сколько стоит ремонт вашей техники","text":"Отправьте Ваш номер телефона, мастер свяжется с Вами и сориентирует по цене","button":"Рассчитать ремонт"},"priceInformation":{"title":"Прайс-лист на услуги","info":"Точная стоимость ремонта техники зависит от ее модели и вида неисправности. Мастеру необходимо выполнить диагностику, прежде чем рассчитать цену. Вот расценки на наши услуги. Цены в таблице только за ремонтные работы, запчасти и комплектующие оплачиваются дополнительно.","minorTitle":"Выезд мастера и диагностика — БЕСПЛАТНО!","text":"В случае отказа от ремонта или его нецелесообразности, требуется оплатить 30 рублей за выезд специалиста и диагностику."}}');

/***/ })

};
;