exports.id = 325;
exports.ids = [325];
exports.modules = {

/***/ 7956:
/***/ ((module) => {

// Exports
module.exports = {
	"section": "workflow_section__fR2Zd",
	"list_header": "workflow_list_header__CaPQp",
	"title": "workflow_title__W1S1y",
	"list_ul": "workflow_list_ul__uqgHn",
	"list_li": "workflow_list_li__u0Lw2",
	"img": "workflow_img__8B0Hz",
	"list_title": "workflow_list_title__bOWcx",
	"list_hidden": "workflow_list_hidden__y8rAX",
	"btn_guaranty": "workflow_btn_guaranty__JzUBl",
	"btn_hidden": "workflow_btn_hidden__gGdpw"
};


/***/ }),

/***/ 5265:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/icon_spoiler_blue.4639eb7a.svg","height":12,"width":20,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 6325:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* reexport safe */ _workflow__WEBPACK_IMPORTED_MODULE_0__.h)
/* harmony export */ });
/* harmony import */ var _workflow__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3411);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_workflow__WEBPACK_IMPORTED_MODULE_0__]);
_workflow__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3411:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ Workflow)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _workflow_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7956);
/* harmony import */ var _workflow_module_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_workflow_module_scss__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _public_images_services_icon_spoiler_blue_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5265);
/* harmony import */ var _constants_json_workflow_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8759);
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6851);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_modal__WEBPACK_IMPORTED_MODULE_6__]);
_modal__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const Workflow = ({ guaranty  })=>{
    const [isShowing, setIsShowing] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const [isShowingModal, setIsShowingModal] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const arrForDraw = guaranty ? _constants_json_workflow_json__WEBPACK_IMPORTED_MODULE_5__/* .garanty */ .l : _constants_json_workflow_json__WEBPACK_IMPORTED_MODULE_5__/* .casual */ .U;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_workflow_module_scss__WEBPACK_IMPORTED_MODULE_7___default().section), "container"),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_workflow_module_scss__WEBPACK_IMPORTED_MODULE_7___default().list_header),
                onClick: ()=>setIsShowing(!isShowing),
                role: "presentation",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: (_workflow_module_scss__WEBPACK_IMPORTED_MODULE_7___default().title),
                        children: "Система работы"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            src: _public_images_services_icon_spoiler_blue_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                            alt: "spoiler",
                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()({
                                "rotate": !isShowing
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_workflow_module_scss__WEBPACK_IMPORTED_MODULE_7___default().list_ul), {
                    [(_workflow_module_scss__WEBPACK_IMPORTED_MODULE_7___default().list_hidden)]: isShowing
                }),
                children: arrForDraw.map((el, ind)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        className: (_workflow_module_scss__WEBPACK_IMPORTED_MODULE_7___default().list_li),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                src: el.image,
                                alt: el.image,
                                width: 74,
                                height: 70,
                                className: (_workflow_module_scss__WEBPACK_IMPORTED_MODULE_7___default().img)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                className: (_workflow_module_scss__WEBPACK_IMPORTED_MODULE_7___default().list_title),
                                children: el.text
                            })
                        ]
                    }, `benefits-${ind}`))
            }),
            guaranty && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_workflow_module_scss__WEBPACK_IMPORTED_MODULE_7___default().btn_guaranty), {
                    [(_workflow_module_scss__WEBPACK_IMPORTED_MODULE_7___default().btn_hidden)]: isShowing
                }),
                onClick: (e)=>{
                    e.preventDefault();
                    e.stopPropagation();
                    setIsShowingModal(!isShowingModal);
                },
                children: "Оставить заявку"
            }),
            isShowingModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modal__WEBPACK_IMPORTED_MODULE_6__/* .Modal */ .u, {
                isShowingModal: isShowingModal,
                setIsShowingModal: setIsShowingModal,
                typeOfModal: "warranty"
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8759:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"U":[{"image":"/images/workflow/icon_workflow_step1.svg","text":"Вы оставляете заявку на ремонт"},{"image":"/images/workflow/icon_workflow_step2.svg","text":"Мастер перезванивает и согласовывает время визита"},{"image":"/images/workflow/icon_workflow_step3.svg","text":"Мастер приезжает, проводит диагностику и сообщает цену ремонта"},{"image":"/images/workflow/icon_workflow_step4.svg","text":"Мастер чинит поломку и даёт письменную гарантию от 6 мес. до 2 лет"}],"l":[{"image":"/images/workflow/icon_workflow_step1.svg","text":"Вы оставляете заявку на ремонт или звоните"},{"image":"/images/workflow/icon_workflow_step2.svg","text":"Мастер находит вас в базе и перезванивает, чтобы уточнить проблему"},{"image":"/images/workflow/icon_workflow_step4.svg","text":"Мастер приезжает, чинит поломку и даёт новую письменную гарантию на ремонт от 3 мес. до 2 лет"}]}');

/***/ })

};
;