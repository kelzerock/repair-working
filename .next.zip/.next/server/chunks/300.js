exports.id = 300;
exports.ids = [300];
exports.modules = {

/***/ 5935:
/***/ ((module) => {

// Exports
module.exports = {
	"section": "repairPrice_section__eF7bS",
	"list_header": "repairPrice_list_header__077ja",
	"title": "repairPrice_title___VCTn",
	"list_ul": "repairPrice_list_ul__p05Pw",
	"list_li": "repairPrice_list_li___2mNt",
	"main_info": "repairPrice_main_info__LyaSS",
	"main_price": "repairPrice_main_price__0PJdP",
	"list_hidden": "repairPrice_list_hidden__SUs3b",
	"about_price": "repairPrice_about_price__ot6Me"
};


/***/ }),

/***/ 6043:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _repairPrice_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5935);
/* harmony import */ var _repairPrice_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_repairPrice_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);





const RepairPrice = ({ data  })=>{
    const [isData, setIsData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        {
            id: 0,
            check: false
        },
        {
            id: 1,
            check: true
        },
        {
            id: 2,
            check: true
        },
        {
            id: 3,
            check: true
        },
        {
            id: 4,
            check: true
        },
        {
            id: 5,
            check: true
        }
    ]);
    const handleAccordionClick = (ind)=>{
        let newData = isData.map((el)=>{
            if (el.id === ind) {
                return {
                    id: el.id,
                    check: !el.check
                };
            } else {
                return {
                    id: el.id,
                    check: el.check
                };
            }
        });
        setIsData(newData);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_repairPrice_module_scss__WEBPACK_IMPORTED_MODULE_4___default().section),
                children: data.map((elem, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_repairPrice_module_scss__WEBPACK_IMPORTED_MODULE_4___default().list_header),
                                onClick: ()=>handleAccordionClick(index),
                                role: "presentation",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: (_repairPrice_module_scss__WEBPACK_IMPORTED_MODULE_4___default().title),
                                        children: elem.title
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            src: "/images/services/icon_spoiler_blue.svg",
                                            width: 12,
                                            height: 7,
                                            alt: "spoiler",
                                            className: classnames__WEBPACK_IMPORTED_MODULE_3___default()({
                                                rotate: !isData[index].check
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_3___default()((_repairPrice_module_scss__WEBPACK_IMPORTED_MODULE_4___default().list_ul), {
                                    [(_repairPrice_module_scss__WEBPACK_IMPORTED_MODULE_4___default().list_hidden)]: isData[index].check
                                }),
                                children: elem.info.map((el, ind)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: (_repairPrice_module_scss__WEBPACK_IMPORTED_MODULE_4___default().list_li),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                className: (_repairPrice_module_scss__WEBPACK_IMPORTED_MODULE_4___default().main_info),
                                                children: el.description
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                className: (_repairPrice_module_scss__WEBPACK_IMPORTED_MODULE_4___default().main_price),
                                                children: el.price
                                            })
                                        ]
                                    }, `price-${ind}`))
                            })
                        ]
                    }, index))
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: (_repairPrice_module_scss__WEBPACK_IMPORTED_MODULE_4___default().about_price),
                children: "Цены действительны c 01.04.2023 по 31.12.2023гг. Стоимость работ приведена справочно, точную стоимость ремонтных работ мастер определяет после диагностики"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RepairPrice);


/***/ }),

/***/ 318:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"washer":{"data":[{"title":"Двигатель","info":[{"description":"Замена щёток","price":"130 - 150 руб."},{"description":"Замена тахо датчика","price":"100 - 180 руб."},{"description":"Замена двигателя","price":"200 - 800 руб. (цена Б/У - новый)"},{"description":"Подшипник в двигателе не меняется, так как он не разборный. Профилактика подшипника","price":"50 - 80 руб."}]},{"title":"Барабан","info":[{"description":"Замена амортизаторов","price":"140 - 200 руб."},{"description":"Замена ТЭНа","price":"120 - 150 руб."},{"description":"Замена подшипника (сальника)","price":"250 - 350 руб."},{"description":"Замена крестовины","price":"300 - 500 руб."},{"description":"Замена бака","price":"от 350 руб."},{"description":"Замена патрубка (верх)","price":"от 120 руб."},{"description":"Замена патрубка (низ)","price":"от 170 руб."},{"description":"Ремонт патрубка","price":"60 - 80 руб."},{"description":"Замена манжет","price":"от 150 руб."}]},{"title":"Насос (помпа)","info":[{"description":"Замена насоса","price":"130 - 170 руб."},{"description":"Замена фильтра","price":"140 - 150 руб."},{"description":"Замена крышки фильтра","price":"от 60 руб."},{"description":"Замена уплотнителя насоса","price":"70 - 100 руб."},{"description":"Замена сливного шланга","price":"70 - 100 руб."},{"description":"Чистка фильтра","price":"60 руб."}]},{"title":"Другое","info":[{"description":"Ремонт модуля управления","price":"130 - 200 руб."},{"description":"Замена модуля управления","price":"от 150 руб."},{"description":"Ремонт электронного модуля","price":"130 - 200 руб."},{"description":"Замена электронного модуля","price":"200 - 400 руб."},{"description":"Чистка фильтра клапана подачи воды","price":"60 руб."},{"description":"Замена клапана подачи воды","price":"120 руб."},{"description":"Замена патрубка подачи воды","price":"50 - 100 руб."},{"description":"Замена пружин","price":"140 - 150 руб."},{"description":"Замена прессостата","price":"180 - 240 руб."},{"description":"Восстановление проводки","price":"50 - 300 руб."},{"description":"Замена датчика температуры","price":"140 руб."},{"description":"Замена подавителя шумов","price":"140 руб."},{"description":"Замена сетевого кабеля","price":"80 - 150 руб."},{"description":"Ремонт сетевого кабеля","price":"60 - 80 руб."},{"description":"Ремонт люка","price":"100 руб."},{"description":"Замена люка","price":"от 250 руб."},{"description":"Замена ремня","price":"60 - 100 руб."},{"description":"Вызов мастера и диагностика","price":"20 - 30 руб."},{"description":"Доставка техники в мастерскую и обратно","price":"40 - 50 руб. (25 руб. в одну сторону без диагностики)"},{"description":"Доставка мелкой бытовой техники","price":"15 - 20 руб. в одну сторону"}]}]},"dryer":{"data":[{"title":"МАЛЫЙ РЕМОНТ","info":[{"description":"Чистка","price":"от 100 до 250 руб."},{"description":"Замена ворсовых фильтров","price":"от 130 руб."},{"description":"Замена кнопки","price":"от 120 руб."},{"description":"Замена рукуператора","price":"от 70 руб."}]},{"title":"СРЕДНИЙ РЕМОНТ","info":[{"description":"Замена пускового конденсатора","price":"от 120 руб."},{"description":"Замена ремня","price":"от 250 руб."},{"description":"Замена опорного ролика","price":"от 250 руб."},{"description":"Замена ТЭНа","price":"от 120 руб."},{"description":"Замена датчика температуры","price":"от 140 руб."}]},{"title":"КРУПНЫЙ РЕМОНТ","info":[{"description":"Замена сенсора влажности","price":"от 150 руб."},{"description":"Замена вентелятора","price":"от 200 руб."},{"description":"Ремонт электродвигателя","price":"от 180 руб."},{"description":"Чистка компрессора теплового насоса","price":"от 80 руб."},{"description":"Замена бака","price":"от 250 руб."},{"description":"Ремонт модуля индикации","price":"от 130 руб."},{"description":"Замена подшипника","price":"от 250 руб."}]},{"title":"Другое","info":[{"description":"Вызов мастера и диагностика","price":"20 - 30 руб."},{"description":"Доставка техники в мастерскую и обратно","price":"40 - 50 руб. (25 руб. в одну сторону без диагностики)"},{"description":"Доставка мелкой бытовой техники","price":"15 - 20 руб. в одну сторону"}]}]},"dishwasher":{"data":[{"title":"Двигатель","info":[{"description":"Замена щёток","price":"130 - 150 руб."},{"description":"Замена тахо датчика","price":"100 - 180 руб."},{"description":"Замена двигателя","price":"200 - 800 руб. (цена Б/У - новый)"},{"description":"Подшипник в двигателе не меняется, так как он не разборный. Профилактика подшипника","price":"50 - 80 руб."}]},{"title":"Барабан","info":[{"description":"Замена амортизаторов","price":"140 - 200 руб."},{"description":"Замена ТЭНа","price":"120 - 150 руб."},{"description":"Замена подшипника (сальника)","price":"250 - 350 руб."},{"description":"Замена крестовины","price":"300 - 500 руб."},{"description":"Замена бака","price":"от 350 руб."},{"description":"Замена патрубка (верх)","price":"от 120 руб."},{"description":"Замена патрубка (низ)","price":"от 170 руб."},{"description":"Ремонт патрубка","price":"60 - 80 руб."},{"description":"Замена манжет","price":"от 150 руб."}]},{"title":"Насос (помпа)","info":[{"description":"Замена насоса","price":"130 - 170 руб."},{"description":"Замена фильтра","price":"140 - 150 руб."},{"description":"Замена крышки фильтра","price":"от 60 руб."},{"description":"Замена уплотнителя насоса","price":"70 - 100 руб."},{"description":"Замена сливного шланга","price":"70 - 100 руб."},{"description":"Чистка фильтра","price":"60 руб."}]},{"title":"Другое","info":[{"description":"Ремонт модуля управления","price":"130 - 200 руб."},{"description":"Замена модуля управления","price":"от 150 руб."},{"description":"Ремонт электронного модуля","price":"130 - 200 руб."},{"description":"Замена электронного модуля","price":"200 - 400 руб."},{"description":"Чистка фильтра клапана подачи воды","price":"60 руб."},{"description":"Замена клапана подачи воды","price":"120 руб."},{"description":"Замена патрубка подачи воды","price":"50 - 100 руб."},{"description":"Замена пружин","price":"140 - 150 руб."},{"description":"Замена прессостата","price":"180 - 240 руб."},{"description":"Восстановление проводки","price":"50 - 300 руб."},{"description":"Замена датчика температуры","price":"140 руб."},{"description":"Замена подавителя шумов","price":"140 руб."},{"description":"Замена сетевого кабеля","price":"80 - 150 руб."},{"description":"Ремонт сетевого кабеля","price":"60 - 80 руб."},{"description":"Ремонт люка","price":"100 руб."},{"description":"Замена люка","price":"от 250 руб."},{"description":"Замена ремня","price":"60 - 100 руб."},{"description":"Герметизация","price":"от 150 руб."},{"description":"Чистка","price":"70 - 150 руб."},{"description":"Замена аквастопа","price":"300 - 500 руб."},{"description":"Замена замка","price":"от 120 руб."},{"description":"Замена лопасти (пайка)","price":"70 - 200 руб."},{"description":"Вызов мастера и диагностика","price":"20 - 30 руб."},{"description":"Доставка техники в мастерскую и обратно","price":"40 - 50 руб. (25 руб. в одну сторону без диагностики)"},{"description":"Доставка мелкой бытовой техники","price":"15 - 20 руб. в одну сторону"}]}]},"hob":{"data":[{"title":"КРУПНЫЙ РЕМОНТ","info":[{"description":"Замена стекла","price":"от 130 руб."},{"description":"Замена конфорок","price":"от 140 руб."},{"description":"Замена стекла","price":"от 600 руб."}]},{"title":"Другое","info":[{"description":"Вызов мастера и диагностика","price":"20 - 30 руб."},{"description":"Доставка техники в мастерскую и обратно","price":"40 - 50 руб. (25 руб. в одну сторону без диагностики)"},{"description":"Доставка мелкой бытовой техники","price":"15 - 20 руб. в одну сторону"}]}]},"oven":{"data":[{"title":"СРЕДНИЙ РЕМОНТ","info":[{"description":"Замена ТЭНа (вверх, низ, конвекция)","price":"от 120 руб."},{"description":"Замена уплотнителя дверцы","price":"от 150 руб."},{"description":"Замена термостата","price":"от 140 руб."},{"description":"Замена датчика перегрева (обдува)","price":"от 70 руб."},{"description":"Замена вентилятора конвекции","price":"от 200 руб."},{"description":"Проклейка дверцы (стекла)","price":"от 70 руб."},{"description":"Замена стекла (не оригинал)","price":"от 250 руб."},{"description":"Замена (ремонт) программатора","price":"от 80 руб."},{"description":"Ремонт (замена) электронного модуля","price":"от 120 руб."},{"description":"Замена лампы подсветки","price":"от 50 руб."}]},{"title":"Другое","info":[{"description":"Вызов мастера и диагностика","price":"20 - 30 руб."},{"description":"Доставка техники в мастерскую и обратно","price":"40 - 50 руб. (25 руб. в одну сторону без диагностики)"},{"description":"Доставка мелкой бытовой техники","price":"15 - 20 руб. в одну сторону"}]}]},"stove":{"data":[{"title":"МАЛЫЙ РЕМОНТ","info":[{"description":"Ремонт электропроводки","price":"от 50 руб."},{"description":"Замена лампочки подсветки в духовке","price":"от 50 руб."},{"description":"Ремонт или замена чугунной конфорки","price":"от 140 руб."},{"description":"Ремонт или замена конфорки керамической плиты (стеклокерамика)","price":"от 140 руб."}]},{"title":"СРЕДНИЙ РЕМОНТ","info":[{"description":"Ремонт или замена конфорки с расширением (стеклокерамика)","price":"от 140 руб."},{"description":"Ремонт или замена регулятора мощности конфорки (РЭМа)","price":"от 130 руб."},{"description":"Ремонт или замена клеммной коробки","price":"от 140 руб."},{"description":"Замена термостата (терморегулятора)","price":"от 140 руб."},{"description":"Замена таймера духовки","price":"от 140 руб."},{"description":"Замена ТЭНа духовки","price":"от 120 руб."}]},{"title":"КРУПНЫЙ РЕМОНТ","info":[{"description":"Ремонт или замена вентилятора духовки","price":"от 200 руб."},{"description":"Ремонт или замена платы сенсорного управления (стеклокерамика)","price":"от 150 руб."},{"description":"Ремонт или замена модуля управления","price":"от 120 руб."},{"description":"Замена стекла (не оригинал)","price":"от 250 руб."}]},{"title":"Другое","info":[{"description":"Вызов мастера и диагностика","price":"20 - 30 руб."},{"description":"Доставка техники в мастерскую и обратно","price":"40 - 50 руб. (25 руб. в одну сторону без диагностики)"},{"description":"Доставка мелкой бытовой техники","price":"15 - 20 руб. в одну сторону"}]}]}}');

/***/ })

};
;